package com.rajabi.second.firstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.rajabi.second.firstapplication.databinding.ActivityMainBinding;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private static final String NAME = "name";
    private static final String BOOL = "bool";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareTextOnly(binding.editTextTextPersonName.getText().toString());
//                ContentValues values = new ContentValues();
//                values.put(NotesMetaData.NotesTable.TITLE, binding.editTextTextPersonName.getText().toString());
//                values.put(NotesMetaData.NotesTable.CONTENT, binding.editTextTextPersonName.getText().toString());
//                getContentResolver().insert(NotesMetaData.CONTENT_URI, values);
            }
        });
    }


    private void shareTextOnly(String title) {
        Info info =new Info();
        info.setTitle(title);
        info.setBool(false);
        Intent intentt = new Intent(Intent.ACTION_SEND);
        intentt.setPackage("com.rajabi.second.application");
        intentt.setClassName("com.rajabi.second.application", "com.rajabi.second.application.presentation.MainActivity");
        intentt.setType("text/plain");
        intentt.putExtra("name",title);
        intentt.putExtra("bool",false);
        startActivity(intentt);
    }
}