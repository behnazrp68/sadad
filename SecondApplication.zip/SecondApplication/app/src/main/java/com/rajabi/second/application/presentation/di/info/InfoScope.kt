package com.rajabi.second.application.presentation.di.info

@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation  class InfoScope