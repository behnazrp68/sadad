package com.rajabi.second.application.data.repository.datasourceimpl

import android.content.Intent
import com.rajabi.second.application.data.model.Info
import com.rajabi.second.application.data.repository.datasource.InfoRemoteDataSource

class InfoRemoteDataSourceImpl() :InfoRemoteDataSource {
    override suspend fun getInfo(): Info? {

        return Intent.getIntentOld("name")  as? Info
    }
}