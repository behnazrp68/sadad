package com.rajabi.second.application.presentation.di.core

import com.rajabi.second.application.data.model.Info
import dagger.Module


@Module
class InfoModule {


}